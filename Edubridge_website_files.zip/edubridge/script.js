const quizData = {
  math: [
    { q: "What is 8 × 7?", options: ["54", "56", "64", "48"], answer: "56", explanation: "Correct! 8 multiplied by 7 equals 56." },
    { q: "What is 25% of 80?", options: ["10", "15", "20", "25"], answer: "20", explanation: "Correct! 25% is one quarter, and one quarter of 80 is 20." },
    { q: "Solve: 3x = 21", options: ["x = 6", "x = 7", "x = 8", "x = 9"], answer: "x = 7", explanation: "Correct! Divide both sides by 3 to get x = 7." }
  ],
  swahili: [
    { q: "What does “Habari za asubuhi?” mean?", options: ["Good night", "Good morning / morning news", "Thank you", "Goodbye"], answer: "Good morning / morning news", explanation: "Ndiyo! “Habari za asubuhi?” is a common morning greeting." },
    { q: "How do you say “thank you” in Kiswahili?", options: ["Karibu", "Pole", "Asante", "Tafadhali"], answer: "Asante", explanation: "Sahihi! “Asante” means “thank you.”" },
    { q: "What does “maji” mean in English?", options: ["Food", "Water", "School", "Friend"], answer: "Water", explanation: "Sahihi! “Maji” means “water.”" }
  ],
  english: [
    { q: "Choose the grammatically correct sentence.", options: ["She go to school.", "She going school.", "She goes to school.", "She gone to school."], answer: "She goes to school.", explanation: "Correct! With “she” in the simple present, use “goes.”" },
    { q: "Which word is closest in meaning to “begin”?", options: ["Finish", "Start", "Forget", "Wait"], answer: "Start", explanation: "Correct! “Start” is a synonym of “begin.”" },
    { q: "What is the plural of “child”?", options: ["Childs", "Childes", "Children", "Childrens"], answer: "Children", explanation: "Correct! The plural of “child” is “children.”" }
  ]
};

const subjectNames = { math: "MATHEMATICS", swahili: "KISWAHILI", english: "ENGLISH" };
let currentSubject = "math";
let currentIndex = 0;
let score = 0;
let answered = false;
let totalAnswered = 0;

const questionSubject = document.getElementById("questionSubject");
const questionCount = document.getElementById("questionCount");
const questionText = document.getElementById("questionText");
const answerOptions = document.getElementById("answerOptions");
const feedback = document.getElementById("feedback");
const nextButton = document.getElementById("nextQuestion");
const scoreDisplay = document.getElementById("score");

function renderQuestion() {
  const question = quizData[currentSubject][currentIndex];
  answered = false;
  questionSubject.textContent = subjectNames[currentSubject];
  questionCount.textContent = `QUESTION ${currentIndex + 1} OF ${quizData[currentSubject].length}`;
  questionText.textContent = question.q;
  answerOptions.replaceChildren();
  question.options.forEach(option => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer-option";
    button.textContent = option;
    button.addEventListener("click", () => chooseAnswer(button, option, question));
    answerOptions.appendChild(button);
  });
  feedback.textContent = "Choose the answer you think is correct.";
  feedback.className = "quiz-feedback";
  nextButton.disabled = true;
  nextButton.textContent = currentIndex === quizData[currentSubject].length - 1 ? "Finish quiz →" : "Next question →";
  updateScore();
}

function chooseAnswer(button, option, question) {
  if (answered) return;
  answered = true;
  totalAnswered++;
  const buttons = [...answerOptions.querySelectorAll("button")];
  buttons.forEach(item => {
    item.disabled = true;
    if (item.textContent === question.answer) item.classList.add("correct");
  });
  if (option === question.answer) {
    score++;
    feedback.textContent = question.explanation;
    feedback.className = "quiz-feedback good";
  } else {
    button.classList.add("incorrect");
    feedback.textContent = `Not quite. ${question.explanation}`;
    feedback.className = "quiz-feedback bad";
  }
  updateScore();
  nextButton.disabled = false;
}

function updateScore() {
  scoreDisplay.innerHTML = `${score} <small>/ ${totalAnswered}</small>`;
}

function selectSubject(subject) {
  currentSubject = subject;
  currentIndex = 0;
  document.querySelectorAll(".quiz-tab").forEach(tab => tab.classList.toggle("active", tab.dataset.quiz === subject));
  renderQuestion();
}

document.querySelectorAll(".quiz-tab").forEach(tab => {
  tab.addEventListener("click", () => selectSubject(tab.dataset.quiz));
});

document.querySelectorAll("[data-subject]").forEach(button => {
  button.addEventListener("click", () => {
    selectSubject(button.dataset.subject);
    document.getElementById("practice").scrollIntoView({ behavior: "smooth" });
  });
});

nextButton.addEventListener("click", () => {
  if (!answered) return;
  if (currentIndex < quizData[currentSubject].length - 1) {
    currentIndex++;
    renderQuestion();
  } else {
    questionText.textContent = `Quiz complete — you scored ${score} out of ${totalAnswered}.`;
    answerOptions.replaceChildren();
    feedback.textContent = "Great effort! Choose a subject to practise again.";
    feedback.className = "quiz-feedback good";
    questionCount.textContent = "ROUND COMPLETE";
    nextButton.disabled = true;
    nextButton.textContent = "Choose a subject";
  }
});

const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");
menuToggle.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.textContent = "☰";
}));

document.getElementById("year").textContent = new Date().getFullYear();
renderQuestion();
