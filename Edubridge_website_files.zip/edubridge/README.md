# Edubridge

Edubridge is a responsive learning website concept for practising Mathematics, Kiswahili, and English. It is designed to help students learn and help language learners build confidence.

## Files

- `index.html` — page structure and content
- `style.css` — layout, colours, responsive design, and visual styling
- `script.js` — interactive sample quizzes, score display, subject switching, and mobile navigation

## Run locally

1. Download or clone this repository.
2. Keep the three files in the same folder.
3. Open `index.html` in a browser.

No build tools, server, API key, or external libraries are required for this starter version.

## Publish with GitHub Pages

1. Upload all three files to the root of your GitHub repository.
2. Open the repository's **Settings**.
3. Find **Pages** in the repository settings.
4. Under the build/deployment section, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site. The Pages section will show the published URL.

## Important notes

- The quizzes are starter examples and can be expanded with more questions and topics.
- Scores are kept only while the page is open; they are not saved to an account or database.
- This version does not include user accounts, a backend, or a database.
- Review educational content before using it for formal teaching.
